import os
import asyncio
import pytest
from app.services import handle_upload, verify

@pytest.mark.integration
@pytest.mark.skipif(not (os.getenv('PINATA_JWT') or os.getenv('PINATA_API_KEY')), reason='Pinata creds not set')
@pytest.mark.skipif(not (os.getenv('HEDERA_OPERATOR_ID') and os.getenv('HEDERA_OPERATOR_KEY')), reason='Hedera creds not set')
def test_end_to_end_upload_and_verify():
    class DummyFile:
        filename = 'test.txt'
        async def read(self):
            return b'hello proofmesh integration test'

    metadata = {'creator': 'integration-tester', 'model': 'test-model', 'prompt': 'test prompt'}
    loop = asyncio.get_event_loop()
    proof = loop.run_until_complete(handle_upload(DummyFile(), metadata))
    assert 'file_cid' in proof
    assert 'sha256' in proof
    # if topic id exists in proof, try verifying via hedera query
    if proof.get('hedera_topic_id'):
        res = loop.run_until_complete(verify(file=None, proof_json=proof))
        # Might be not yet propagated; at minimum ensure no exception and a dict response
        assert isinstance(res, dict)
    else:
        # If no topic id set, still ensure tx id present
        assert proof.get('hedera_txid')
