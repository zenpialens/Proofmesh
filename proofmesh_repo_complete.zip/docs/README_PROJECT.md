ProofMesh Project Docs

- backend: FastAPI service implementing /upload and /verify
- frontend: Vite + React placeholder app
- smart-contracts: Example solidity contracts for on-chain anchoring (optional)
- docs/: pitch deck, deployment, demo link
