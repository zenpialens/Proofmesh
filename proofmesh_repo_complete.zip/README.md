# ProofMesh

Universal Proof Layer for AI-Generated Content

ProofMesh assigns tamper-proof **Proof Stamps** to content (images, video, audio, text, documents)
by storing large files on IPFS and anchoring hashes & metadata on Hedera Consensus Service (HCS).

## Repo structure
See `docs/` for architecture and pitch deck.

## Quickstart (developer)
0. Ensure you have Python 3.10+, Node.js 18+, Docker (optional)

### Backend (Python / FastAPI)
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### Frontend (React)
```bash
cd frontend
npm install
npm run dev
```

### Smart Contracts
Solidity contracts stored in `smart-contracts/`

## What to include for hackathon submission
- All code and README
- Pitch deck at `docs/pitch_deck.pdf`
- Demo video link in `docs/demo_link.txt`
- Live demo URL in `docs/deployment.md`


## Environment variables (required for production features)

### Pinata (IPFS pinning)
- `PINATA_API_KEY` — Pinata API key (optional if using JWT)
- `PINATA_SECRET_API_KEY` — Pinata secret (optional if using JWT)
- `PINATA_JWT` — Pinata JWT (recommended for production)

### Infura / Web3.Storage (optional)
- `INFURA_PROJECT_ID`
- `INFURA_PROJECT_SECRET`

### Hedera
- `HEDERA_OPERATOR_ID` — Your Hedera account ID (e.g., 0.0.x)
- `HEDERA_OPERATOR_KEY` — Your Hedera private key
- `HEDERA_NETWORK` — `testnet` (default) or `mainnet`
- `HEDERA_TOPIC_ID` — (optional) use an existing topic; if not provided the app will create a temporary topic

## How Hedera + IPFS integration works in this repo

- `backend/app/ipfs_client.py` implements Pinata uploads (pinFileToIPFS and pinJSONToIPFS). It falls back to a deterministic mock CID for local development when credentials are absent or requests fail.
- `backend/app/hedera_client.py` attempts to use the Hedera SDK. When the SDK is installed and `HEDERA_OPERATOR_*` env vars are set, anchors will be written to HCS topics. Otherwise a mock transaction id is returned for testing.

## Installing dependencies

### Backend
```
cd backend
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
# If you want to use Hedera SDK features:
pip install hedera-sdk
```

### Frontend
```
cd frontend
npm install
npm run dev
```

## Running locally (example)
Start the backend:
```
cd backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Example curl to upload via Pinata/real flow:
```
curl -X POST http://localhost:8000/upload \
  -F 'file=@./sample.jpg' \
  -F 'creator=alice' \
  -F 'model=gpt-image-1' \
  -F 'prompt=...'
```

## Notes on credentials and security
- Do NOT commit your Pinata or Hedera secrets to source control.
- For CI, use GitHub Actions secrets to store `PINATA_JWT` or `HEDERA_OPERATOR_KEY`.


## Integration tests (Pinata + Hedera)

There is an integration test `backend/tests/test_integration.py` which is marked `@pytest.mark.integration`. It will be skipped unless you set the following environment variables:

- `PINATA_JWT` or `PINATA_API_KEY` & `PINATA_SECRET_API_KEY`
- `HEDERA_OPERATOR_ID` and `HEDERA_OPERATOR_KEY`

Run integration tests locally like this (ensure env vars are set):
```
cd backend
pytest -q -m integration
```

## Docker Compose (local development)

Start the stack with:
```
docker-compose up --build
```
This will build and run both the backend (on port 8000) and frontend (on port 3000). Provide credentials via environment variables when running docker-compose, for example:

```
PINATA_JWT=... HEDERA_OPERATOR_ID=0.0.x HEDERA_OPERATOR_KEY=... docker-compose up --build
```

Security note: Never commit secrets to the repository. Use CI secrets for automated testing.
