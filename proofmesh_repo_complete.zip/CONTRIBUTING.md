# Contributing to ProofMesh

Thanks for your interest in contributing to ProofMesh! We welcome bug reports, documentation
improvements, tests, and feature contributions.

## How to contribute

1. Fork the repository.
2. Create a feature branch: `git checkout -b feat/my-feature`
3. Write tests for new features or bug fixes.
4. Run `pytest` in `backend` to ensure tests pass.
5. Open a PR describing your changes.

## Code style
- Python: follow PEP8. Use black / isort if possible.
- JavaScript: follow standard or eslint rules.

## Testing
- Backend tests live in `backend/tests/`. Use `pytest`.
- Frontend tests are optional.

## Security
- Do not commit secrets or private keys.
- For local testing, use mock env vars.

## CI
The repository contains a GitHub Actions workflow `.github/workflows/ci.yml` that runs backend tests on pushes and PRs.

## Getting help
Open an issue and tag the maintainers (see CODEOWNERS).
