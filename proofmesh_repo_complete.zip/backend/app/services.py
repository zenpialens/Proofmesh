import hashlib, json, asyncio, os
from fastapi import UploadFile
from . import ipfs_client, hedera_client

async def handle_upload(file: UploadFile, metadata: dict):
    # read file bytes
    contents = await file.read()
    sha256 = hashlib.sha256(contents).hexdigest()
    # upload to IPFS
    cid = ipfs_client.upload_bytes(contents, filename=getattr(file, 'filename', 'file'))
    # create proof object
    proof = {
        "file_cid": cid,
        "sha256": sha256,
        "timestamp": int(asyncio.get_event_loop().time()),
        "creator": metadata.get("creator"),
        "model": metadata.get("model"),
        "prompt": metadata.get("prompt"),
        "edits": metadata.get("edits"),
        "version": metadata.get("version", 1),
        "previous_proof": metadata.get("previous_proof")
    }
    # anchor to Hedera (this will create or use a topic)
    tx_id = hedera_client.anchor_proof(proof)
    proof["hedera_txid"] = tx_id
    # include topic id if available from env var
    topic_id = os.getenv('HEDERA_TOPIC_ID')
    if topic_id:
        proof['hedera_topic_id'] = topic_id
    else:
        # attempt to get created topic by parsing tx_id if possible (not reliable) - leave empty
        proof['hedera_topic_id'] = topic_id or None
    # construct verification URL (placeholder)
    proof['verification_url'] = f"/verify/proof/{cid}"
    return proof

async def verify(file: UploadFile = None, proof_json: dict = None):
    # If file is provided, compute hash and compare
    if file and proof_json:
        contents = await file.read()
        sha256 = hashlib.sha256(contents).hexdigest()
        expected = proof_json.get('sha256')
        return {'match': sha256 == expected, 'computed': sha256, 'expected': expected}
    if proof_json and proof_json.get('hedera_topic_id'):
        # attempt to query hedera topic for messages and find matching proof by cid/sha256
        topic_id = proof_json.get('hedera_topic_id')
        try:
            messages = hedera_client.query_topic_messages(topic_id)
        except Exception as e:
            return {'error': str(e)}
        # search for matching proof
        for m in messages:
            cj = m.get('contents_json')
            if not cj:
                continue
            if cj.get('file_cid') == proof_json.get('file_cid') or cj.get('sha256') == proof_json.get('sha256'):
                return {'match': True, 'message': cj, 'sequence_number': m.get('sequence_number')}
        return {'match': False, 'reason': 'not found on topic'}
    return {'error': 'insufficient inputs'}
