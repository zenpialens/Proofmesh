// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract AuditLog {
    event AuditEntry(string description, uint256 timestamp, address indexed by);

    function log(string memory description) public {
        emit AuditEntry(description, block.timestamp, msg.sender);
    }
}
