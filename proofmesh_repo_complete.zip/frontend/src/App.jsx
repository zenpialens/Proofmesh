import React from 'react'

export default function App(){
  return (
    <div style={{fontFamily:'Arial, sans-serif', padding:40}}>
      <h1>ProofMesh (Preview)</h1>
      <p>Frontend placeholder. Connect to backend /upload and /verify endpoints.</p>
    </div>
  )
}
