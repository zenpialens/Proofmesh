\
    import os, json, time
    from typing import Dict, Optional, List

    HEDERA_OPERATOR_ID = os.getenv('HEDERA_OPERATOR_ID')  # e.g. "0.0.12345"
    HEDERA_OPERATOR_KEY = os.getenv('HEDERA_OPERATOR_KEY')  # private key string
    HEDERA_NETWORK = os.getenv('HEDERA_NETWORK', 'testnet')  # 'testnet' or 'mainnet'
    HEDERA_TOPIC_ID = os.getenv('HEDERA_TOPIC_ID')  # optional pre-created topic id
    HEDERA_TOPIC_MEMO = os.getenv('HEDERA_TOPIC_MEMO', 'ProofMesh provenance topic')

    # Try to import Hedera SDK
    try:
        from hedera import (
            Client,
            TopicCreateTransaction,
            TopicMessageSubmitTransaction,
            TopicId,
            TopicMessageQuery,
            PrivateKey,
            AccountId,
        )
        SDK_AVAILABLE = True
    except Exception as e:
        print('Hedera SDK not available:', e)
        SDK_AVAILABLE = False

    def _make_client() -> Optional['Client']:
        if not SDK_AVAILABLE:
            return None
        if HEDERA_NETWORK == 'mainnet':
            client = Client.for_mainnet()
        else:
            client = Client.for_testnet()
        if HEDERA_OPERATOR_ID and HEDERA_OPERATOR_KEY:
            client.set_operator(AccountId.fromString(HEDERA_OPERATOR_ID), PrivateKey.fromString(HEDERA_OPERATOR_KEY))
        return client

    def ensure_topic() -> str:
        \"\"\"Ensure there is a topic to submit messages to. Returns TopicId string.
        If HEDERA_TOPIC_ID env var is set, returns that. Otherwise creates a topic and returns its id.
        Note: creating a topic requires operator credentials.
        \"\"\"
        if HEDERA_TOPIC_ID:
            return HEDERA_TOPIC_ID
        if not SDK_AVAILABLE:
            # For local dev return a mock topic id
            return f\"mock-topic-{int(time.time())}\"
        client = _make_client()
        if client is None:
            return f\"mock-topic-{int(time.time())}\"
        # Create topic with memo
        tx = TopicCreateTransaction().set_memo(HEDERA_TOPIC_MEMO)
        resp = tx.execute(client)
        receipt = resp.get_receipt(client)
        tid = receipt.topic_id
        try:
            return tid.toString()
        except Exception:
            return str(tid)

    def anchor_proof(proof: Dict) -> str:
        \"\"\"Anchor proof (JSON serializable) to Hedera Consensus Service topic.
        Returns a transaction id string.
        \"\"\"
        payload = json.dumps(proof, sort_keys=True)
        topic_id = ensure_topic()
        if not SDK_AVAILABLE:
            return _mock_txid(payload)
        client = _make_client()
        if client is None:
            return _mock_txid(payload)
        # Convert to TopicId object
        try:
            tid_obj = TopicId.fromString(topic_id)
        except Exception:
            # If parsing fails, create temporary topic
            receipt = TopicCreateTransaction().set_memo(HEDERA_TOPIC_MEMO).execute(client).get_receipt(client)
            tid_obj = receipt.topic_id
        # Submit message
        tx = TopicMessageSubmitTransaction().set_topic_id(tid_obj).set_message(payload.encode('utf-8'))
        resp = tx.execute(client)
        try:
            txid = resp.transaction_id.toString()
        except Exception:
            txid = f\"hedera-tx-{int(time.time())}\"
        return str(txid)

    def query_topic_messages(topic_id: str, start_time: Optional[int] = None, end_time: Optional[int] = None) -> List[Dict]:
        \"\"\"Query messages for a topic ID. Returns list of dicts with sequence numbers, consensus timestamps and message content (JSON parsed when possible).
        Uses TopicMessageQuery. Requires SDK availability.
        \"\"\"
        results = []
        if not SDK_AVAILABLE:
            raise RuntimeError('Hedera SDK is not available in the environment.')
        client = _make_client()
        if client is None:
            raise RuntimeError('Hedera client could not be created. Check operator env vars.')
        try:
            tid = TopicId.fromString(topic_id)
        except Exception as e:
            raise ValueError(f'Invalid topic id: {topic_id} - {e}')
        # Build query; this returns an iterator of messages
        q = TopicMessageQuery().set_topic_id(tid)
        if start_time:
            # start_time is unix epoch seconds
            from hedera import Timestamp
            q = q.set_start_time(Timestamp(start_time, 0))
        if end_time:
            from hedera import Timestamp
            q = q.set_end_time(Timestamp(end_time, 0))
        # Execute query
        for msg in q.execute(client):
            try:
                content = msg.contents.decode('utf-8')
            except Exception:
                content = None
            entry = {
                'sequence_number': getattr(msg, 'sequence_number', None),
                'consensus_timestamp': getattr(msg, 'consensus_timestamp', None),
                'contents_raw': content,
                'contents_json': None
            }
            if content:
                try:
                    entry['contents_json'] = json.loads(content)
                except Exception:
                    entry['contents_json'] = None
            results.append(entry)
        return results

    def _mock_txid(payload: str) -> str:
        import hashlib
        h = hashlib.sha256(payload.encode()).hexdigest()
        return f\"mock-tx-{h[:12]}\"
