import asyncio
from app.services import handle_upload

async def test_upload(tmp_path):
    class Dummy:
        filename = "file.txt"
        async def read(self):
            return b"hello world"

    result = await handle_upload(Dummy(), {"creator":"alice"})
    assert "file_cid" in result
