from fastapi import FastAPI, UploadFile, File, Form
from app import services
from pydantic import BaseModel
app = FastAPI(title="ProofMesh API")

class Metadata(BaseModel):
    creator: str | None = None
    model: str | None = None
    prompt: str | None = None
    edits: str | None = None
    version: int | None = 1
    previous_proof: str | None = None

@app.post("/upload")
async def upload(file: UploadFile = File(...), creator: str = Form(None), model: str = Form(None), prompt: str = Form(None), edits: str = Form(None), previous_proof: str = Form(None)):
    metadata = {
        "creator": creator,
        "model": model,
        "prompt": prompt,
        "edits": edits,
        "previous_proof": previous_proof
    }
    result = await services.handle_upload(file, metadata)
    return result

@app.post("/verify")
async def verify(file: UploadFile = File(None), proof_json: dict = None):
    result = await services.verify(file, proof_json)
    return result
