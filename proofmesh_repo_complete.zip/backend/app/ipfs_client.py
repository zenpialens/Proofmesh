import os
import io
import requests
import json

PINATA_API_KEY = os.getenv('PINATA_API_KEY')
PINATA_SECRET_API_KEY = os.getenv('PINATA_SECRET_API_KEY')
PINATA_JWT = os.getenv('PINATA_JWT')  # optional: recommended for production
INFURA_PROJECT_ID = os.getenv('INFURA_PROJECT_ID')
INFURA_PROJECT_SECRET = os.getenv('INFURA_PROJECT_SECRET')

def _pinata_headers():
    if PINATA_JWT:
        return {'Authorization': f'Bearer {PINATA_JWT}'}
    elif PINATA_API_KEY and PINATA_SECRET_API_KEY:
        return {
            'pinata_api_key': PINATA_API_KEY,
            'pinata_secret_api_key': PINATA_SECRET_API_KEY
        }
    else:
        return {}

def upload_bytes(data: bytes, filename: str = 'file') -> str:
    """Upload bytes to IPFS using Pinata (preferred) or return a deterministic mock CID.

    Returns the IPFS CID (string).
    """
    # Try Pinata first
    try:
        if PINATA_API_KEY or PINATA_JWT:
            url = 'https://api.pinata.cloud/pinning/pinFileToIPFS'
            files = {
                'file': (filename, io.BytesIO(data))
            }
            headers = _pinata_headers()
            resp = requests.post(url, files=files, headers=headers, timeout=30)
            resp.raise_for_status()
            j = resp.json()
            # Pinata returns IpfsHash
            return j.get('IpfsHash') or j.get('IpfsHash', '')
    except Exception as e:
        # don't fail hard here; fallback to other providers
        print('Pinata upload failed:', e)

    # Optionally: Infura / Web3.storage implementations can be added here.
    # If no service available, return a deterministic mock CID (useful for local dev / tests)
    import hashlib
    digest = hashlib.sha256(data).hexdigest()
    mock_cid = 'bafy' + digest[:40]
    return mock_cid

def pin_json(obj: dict) -> str:
    """Pin JSON metadata to IPFS via Pinata pinJSONToIPFS. Returns CID or mock cid."""
    try:
        if PINATA_API_KEY or PINATA_JWT:
            url = 'https://api.pinata.cloud/pinning/pinJSONToIPFS'
            headers = _pinata_headers()
            headers['Content-Type'] = 'application/json'
            resp = requests.post(url, headers=headers, json=obj, timeout=20)
            resp.raise_for_status()
            j = resp.json()
            return j.get('IpfsHash') or j.get('IpfsHash','')
    except Exception as e:
        print('Pinata pinJSONToIPFS failed:', e)

    # Fallback mock cid
    import hashlib, json as _json
    digest = hashlib.sha256(_json.dumps(obj, sort_keys=True).encode()).hexdigest()
    return 'bafy' + digest[:40]
