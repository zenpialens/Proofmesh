// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract ProvenanceRegistry {
    struct Proof {
        string cid;
        string sha256;
        string metadata;
        uint256 timestamp;
        address submitter;
    }

    mapping(bytes32 => Proof) public proofs;

    event ProofAnchored(bytes32 indexed proofHash, string cid, string sha256, address submitter);

    function anchorProof(string memory cid, string memory sha256, string memory metadata) public {
        bytes32 key = keccak256(abi.encodePacked(cid, sha256, block.timestamp));
        proofs[key] = Proof(cid, sha256, metadata, block.timestamp, msg.sender);
        emit ProofAnchored(key, cid, sha256, msg.sender);
    }
}
